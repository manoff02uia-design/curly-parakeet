package com.dumplib.metadata

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

class DumpException(message: String) : Exception(message)

/**
 * Metadata dumper for Unity IL2CPP global-metadata.dat (versions 24-31).
 * Struct sizes are auto-detected and validated against the file, so an
 * unsupported / protected file fails with a clear error instead of garbage output.
 */
object Il2CppMetaDumper {

    fun dump(meta: ByteArray, xorKey: Int, libInfo: String, out: File, progress: (String) -> Unit) {
        if (xorKey != 0) {
            progress("Decoding XOR 0x${"%02X".format(xorKey)} ...")
            val k = xorKey.toByte()
            for (i in meta.indices) meta[i] = (meta[i].toInt() xor k.toInt()).toByte()
        }
        if (meta.size < 256) throw DumpException("Metadata file is too small or corrupted.")
        val bb = ByteBuffer.wrap(meta).order(ByteOrder.LITTLE_ENDIAN)
        if (bb.getInt(0).toUInt() != 0xFAB11BAFu) throw DumpException("Invalid metadata magic.")
        val version = bb.getInt(4)
        if (version < 24 || version > 31) {
            throw DumpException("Unsupported metadata version: $version (supported: 24-31).")
        }

        fun inFile(off: Int, size: Int) = off >= 0 && size >= 0 && off.toLong() + size <= meta.size
        fun u16(i: Int) = bb.getShort(i).toInt() and 0xFFFF
        fun u32(i: Int) = bb.getInt(i).toLong() and 0xFFFFFFFFL

        val strOff = bb.getInt(24); val strSize = bb.getInt(28)
        val methOff = bb.getInt(48); val methSize = bb.getInt(52)
        val fieldOff = bb.getInt(96); val fieldSize = bb.getInt(100)
        val tdOff = bb.getInt(160); val tdSize = bb.getInt(164)

        if (!inFile(strOff, strSize) || !inFile(methOff, methSize) ||
            !inFile(fieldOff, fieldSize) || !inFile(tdOff, tdSize) || tdSize <= 0 || strSize <= 0
        ) {
            throw DumpException("Metadata header is invalid (file may be encrypted or protected).")
        }

        fun str(idx: Int): String? {
            if (idx < 0 || idx >= strSize) return null
            val s = strOff + idx
            val lim = strOff + strSize
            var e = s
            while (e < lim && meta[e].toInt() != 0) e++
            return String(meta, s, e - s, Charsets.UTF_8)
        }

        fun isIdent(s: String?): Boolean =
            s != null && s.isNotEmpty() && s.all { it.code >= 32 && it.code != 127 && it != '\uFFFD' }

        val fieldsTotal = fieldSize / 12

        // ---- detect TypeDefinition struct size ----
        fun checkTd(c: Int): Boolean {
            val n = tdSize / c
            for (i in 0 until n) {
                val b = tdOff + i * c
                if (!isIdent(str(bb.getInt(b)))) return false
                if (str(bb.getInt(b + 4)) == null) return false
                val fs = bb.getInt(b + c - 56)
                val fc = u16(b + c - 20)
                if (fc > 0 && (fs < 0 || fs.toLong() + fc > fieldsTotal)) return false
            }
            return true
        }

        progress("Analyzing metadata v$version ...")
        var ts = -1
        var c = 80
        while (c <= 140) {
            if (tdSize % c == 0 && checkTd(c)) { ts = c; break }
            c += 4
        }
        if (ts < 0) throw DumpException("Cannot detect type table layout (unsupported or protected metadata).")
        val typeCount = tdSize / ts

        // ---- detect MethodDefinition struct size ----
        fun checkM(m: Int): Boolean {
            val n = methSize / m
            for (i in 0 until n) {
                val b = methOff + i * m
                if (!isIdent(str(bb.getInt(b)))) return false
                val dt = bb.getInt(b + 4)
                if (dt < 0 || dt >= typeCount) return false
                val tb = tdOff + dt * ts
                val mstart = bb.getInt(tb + ts - 52)
                val mcount = u16(tb + ts - 24)
                if (i < mstart || i >= mstart + mcount) return false
            }
            return true
        }

        var ms = -1
        var m = 24
        while (m <= 80) {
            if (methSize > 0 && methSize % m == 0 && checkM(m)) { ms = m; break }
            m += 4
        }
        if (ms < 0 && methSize > 0) throw DumpException("Cannot detect method table layout.")

        progress("Types: $typeCount | TypeDef size: $ts | Method size: $ms")

        var totalFields = 0
        var totalMethods = 0
        out.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write("// DUMP LIB + META DATA\n")
            w.write("// Metadata version: $version\n")
            w.write("// LIB: ${if (libInfo.isEmpty()) "n/a" else libInfo}\n")
            w.write("// Types: $typeCount\n")
            w.write("// NOTE: RVA/offsets and field/return type names need the code-registration\n")
            w.write("// scan of the LIB and are not included in this build.\n\n")

            for (i in 0 until typeCount) {
                val b = tdOff + i * ts
                val name = str(bb.getInt(b)) ?: "?"
                val ns = str(bb.getInt(b + 4)) ?: ""
                val flags = u32(b + ts - 60).toInt()
                val fs = bb.getInt(b + ts - 56)
                val mst = bb.getInt(b + ts - 52)
                val mc = u16(b + ts - 24)
                val fc = u16(b + ts - 20)
                val token = u32(b + ts - 4)

                val isInterface = (flags and 0x20) != 0
                w.write("// Namespace: $ns\n")
                w.write(typeMods(flags, isInterface))
                w.write(if (isInterface) "interface " else "class ")
                w.write("$name // TypeDefIndex: $i, Token: 0x${"%08X".format(token)}\n{\n")

                if (fc > 0) {
                    w.write("\t// Fields\n")
                    for (f in fs until fs + fc) {
                        val fb = fieldOff + f * 12
                        val fname = str(bb.getInt(fb)) ?: "?"
                        val ftype = bb.getInt(fb + 4)
                        w.write("\t<type #$ftype> $fname;\n")
                        totalFields++
                    }
                }
                if (mc > 0) {
                    w.write("\t// Methods\n")
                    for (k in mst until mst + mc) {
                        val mb = methOff + k * ms
                        val mname = str(bb.getInt(mb)) ?: "?"
                        val mflags = u16(mb + ms - 8)
                        val pc = u16(mb + ms - 2)
                        val mtoken = u32(mb + ms - 12)
                        w.write("\t${methodMods(mflags)}<ret> $mname($pc params); // Token: 0x${"%08X".format(mtoken)}\n")
                        totalMethods++
                    }
                }
                w.write("}\n\n")
                if (i % 1000 == 999) progress("Dumped ${i + 1} / $typeCount types")
            }
        }
        progress("Total fields: $totalFields | methods: $totalMethods")
    }

    private fun typeMods(f: Int, isInterface: Boolean): String {
        val sb = StringBuilder()
        sb.append(
            when (f and 7) {
                0 -> "internal "
                1, 2 -> "public "
                3 -> "private "
                4 -> "protected "
                5 -> "internal "
                6 -> "private protected "
                else -> "protected internal "
            }
        )
        if (!isInterface) {
            val abs = (f and 0x80) != 0
            val sealed = (f and 0x100) != 0
            if (abs && sealed) sb.append("static ")
            else if (abs) sb.append("abstract ")
            else if (sealed) sb.append("sealed ")
        }
        return sb.toString()
    }

    private fun methodMods(f: Int): String {
        val sb = StringBuilder()
        sb.append(
            when (f and 7) {
                1 -> "private "
                2 -> "private protected "
                3 -> "internal "
                4 -> "protected "
                5 -> "protected internal "
                6 -> "public "
                else -> ""
            }
        )
        if ((f and 0x10) != 0) sb.append("static ")
        if ((f and 0x400) != 0) sb.append("abstract ")
        else if ((f and 0x40) != 0) sb.append("virtual ")
        return sb.toString()
    }
}
