package com.dumplib.metadata

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*

class AiChatActivity : Activity() {
    private lateinit var tvTitle: TextView
    private lateinit var scroll: ScrollView
    private lateinit var box: LinearLayout
    private lateinit var etInput: EditText
    private lateinit var btnSend: Button
    private lateinit var module: AiModule
    private val hist = ArrayList<ChatMessage>()
    private var busy = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        setContentView(R.layout.activity_ai_chat)
        tvTitle  = findViewById(R.id.tvChatTitle)
        scroll   = findViewById(R.id.scrollChat)
        box      = findViewById(R.id.chatMsgBox)
        etInput  = findViewById(R.id.etChatInput)
        btnSend  = findViewById(R.id.btnChatSend)
        findViewById<TextView>(R.id.btnChatBack).setOnClickListener { finish() }

        val id = intent.getStringExtra("moduleId") ?: ""
        val mod = AiModule.load(this).firstOrNull { it.id == id }
        if (mod == null) { Toast.makeText(this,"AI not found",Toast.LENGTH_SHORT).show(); finish(); return }
        module = mod
        tvTitle.text = module.name
        note("Chat with ${module.name} (${module.model})
Type a message and tap Send.")

        btnSend.setOnClickListener { send() }
    }

    private fun send() {
        val txt = etInput.text.toString().trim()
        if (txt.isEmpty() || busy) return
        etInput.setText("")
        userBubble(txt)
        hist.add(ChatMessage("user", txt))
        busy = true; btnSend.isEnabled = false
        val snap = hist.toList()
        val th = note("⏳ ${module.name} is thinking…")
        Thread {
            val r = try { AiNetworkHelper.call(module, snap) }
            catch (t:Throwable) { "Network error: ${t.message}" }
            runOnUiThread {
                box.removeView(th)
                hist.add(ChatMessage("assistant", r))
                aiBubble(r); busy=false; btnSend.isEnabled=true
            }
        }.start()
    }

    private fun dp(v:Int) = (v*resources.displayMetrics.density).toInt()
    private fun scrollBottom() = scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }

    private fun userBubble(txt:String) {
        val tv = TextView(this).apply {
            text=txt; setTextColor(Color.WHITE); textSize=14f; setLineSpacing(4f,1f)
            setPadding(dp(14),dp(10),dp(14),dp(10))
            maxWidth=(resources.displayMetrics.widthPixels*0.78).toInt()
            background=GradientDrawable().apply { cornerRadius=20f*resources.displayMetrics.density; setColor(0xFF0C3D35.toInt()) }
        }
        val lp=LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(60),dp(6),dp(4),dp(6)); lp.gravity=Gravity.END
        box.addView(tv,lp); scrollBottom()
    }

    private fun aiBubble(txt:String) {
        val tv = TextView(this).apply {
            text=txt; setTextColor(0xFFDDEEF0.toInt()); textSize=14f; setLineSpacing(4f,1f)
            setPadding(dp(14),dp(10),dp(14),dp(10))
            maxWidth=(resources.displayMetrics.widthPixels*0.84).toInt()
            background=GradientDrawable().apply {
                cornerRadius=20f*resources.displayMetrics.density
                setColor(0xFF0E2730.toInt())
                setStroke((1f*resources.displayMetrics.density).toInt(), 0x601DE9D1.toInt())
            }
        }
        val lp=LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(4),dp(6),dp(60),dp(6)); lp.gravity=Gravity.START
        box.addView(tv,lp); scrollBottom()
    }

    fun note(txt:String): View {
        val tv=TextView(this).apply {
            text=txt; setTextColor(0xFF8FB3BA.toInt()); textSize=12f; gravity=Gravity.CENTER
            setPadding(dp(10),dp(4),dp(10),dp(4))
        }
        val lp=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0,dp(2),0,dp(2)); box.addView(tv,lp); scrollBottom(); return tv
    }
}
