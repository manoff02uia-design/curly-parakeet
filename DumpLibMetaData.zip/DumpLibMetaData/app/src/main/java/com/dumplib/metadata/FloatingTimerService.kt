package com.dumplib.metadata

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Floating, draggable counter (1, 2, 3, ...) drawn over other apps. */
class FloatingTimerService : Service() {

    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.dumplib.metadata.STOP_TIMER"
        private const val CHANNEL = "floating_timer"
    }

    private lateinit var wm: WindowManager
    private var root: View? = null
    private lateinit var tvCount: TextView
    private lateinit var btnPause: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var startAt = 0L
    private var pausedAt = 0L
    private var paused = false

    private val tick = object : Runnable {
        override fun run() {
            tvCount.text = (elapsed() / 1000 + 1).toString()
            handler.postDelayed(this, 200)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground()
        if (root == null) {
            if (!Settings.canDrawOverlays(this)) {
                stopSelf()
                return START_NOT_STICKY
            }
            addOverlay()
        }
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Floating timer", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, FloatingTimerService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
            "Stop", stopPi
        ).build()
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Floating timer is running")
            .setContentText("Counting from 1. Drag the box to move it.")
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .addAction(stopAction)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun elapsed(): Long =
        (if (paused) pausedAt else SystemClock.elapsedRealtime()) - startAt

    private fun addOverlay() {
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(14), px(6), px(6), px(6))
            background = GradientDrawable().apply {
                cornerRadius = 28 * dp
                setColor(0xE60B1A1F.toInt())
                setStroke(px(2), 0xFF1DE9D1.toInt())
            }
        }
        tvCount = TextView(this).apply {
            text = "1"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            minWidth = px(44)
        }
        fun small(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label
            setTextColor(0xFF1DE9D1.toInt())
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(px(12), px(6), px(12), px(6))
            setOnClickListener { onClick() }
        }
        btnPause = small("||") { togglePause() }
        val btnReset = small("\u21BA") { resetCount() }
        val btnClose = small("\u2715") { stopSelf() }
        row.addView(tvCount)
        row.addView(btnPause)
        row.addView(btnReset)
        row.addView(btnClose)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = px(24)
            y = px(160)
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        row.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - touchX).toInt()
                    lp.y = startY + (e.rawY - touchY).toInt()
                    wm.updateViewLayout(row, lp)
                    true
                }
                else -> false
            }
        }

        startAt = SystemClock.elapsedRealtime()
        paused = false
        wm.addView(row, lp)
        root = row
        handler.post(tick)
    }

    private fun togglePause() {
        val now = SystemClock.elapsedRealtime()
        if (!paused) {
            paused = true
            pausedAt = now
            btnPause.text = "\u25B6"
        } else {
            startAt += now - pausedAt
            paused = false
            btnPause.text = "||"
        }
    }

    private fun resetCount() {
        val now = SystemClock.elapsedRealtime()
        startAt = now
        pausedAt = now
        tvCount.text = "1"
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        root?.let {
            try { wm.removeView(it) } catch (_: Exception) { }
        }
        root = null
        running = false
        super.onDestroy()
    }
}
