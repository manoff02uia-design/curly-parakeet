package com.dumplib.metadata

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        const val REQ_PICK = 1001
        const val MSG_INVALID = "Please send a different file. This file is invalid."
    }

    private lateinit var tvStatus: TextView
    private lateinit var tvLog: TextView
    private lateinit var scrollLog: ScrollView
    private lateinit var progress: ProgressBar
    private lateinit var btnSend: Button
    private lateinit var choiceBox: LinearLayout
    private lateinit var btn1: Button
    private lateinit var btn2: Button
    private lateinit var btnTimer: Button

    private var libUri: Uri? = null
    private var libInfo = ""
    private var metaUri: Uri? = null
    private var metaXor = 0
    private var dumpFile: File? = null
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvStatus = findViewById(R.id.tvStatus)
        tvLog = findViewById(R.id.tvLog)
        scrollLog = findViewById(R.id.scrollLog)
        progress = findViewById(R.id.progress)
        btnSend = findViewById(R.id.btnSend)
        choiceBox = findViewById(R.id.choiceBox)
        btn1 = findViewById(R.id.btn1)
        btn2 = findViewById(R.id.btn2)

        btnSend.setOnClickListener { if (!busy) openPicker() }
        findViewById<Button>(R.id.btnAi).setOnClickListener {
            startActivity(android.content.Intent(this, AiListActivity::class.java))
        }
        btnTimer = findViewById(R.id.btnTimer)
        btnTimer.setOnClickListener { toggleTimer() }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3001)
        }
        btn1.setOnClickListener { downloadDump() }
        btn2.setOnClickListener { saveDump() }
    }

    override fun onResume() {
        super.onResume()
        updateTimerButton()
    }

    private fun updateTimerButton() {
        btnTimer.text = if (FloatingTimerService.running) "STOP FLOATING TIMER" else "FLOATING TIMER"
    }

    private fun toggleTimer() {
        if (FloatingTimerService.running) {
            stopService(Intent(this, FloatingTimerService::class.java))
            btnTimer.text = "FLOATING TIMER"
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Allow \"Display over other apps\" for this app, then press the button again.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        startForegroundService(Intent(this, FloatingTimerService::class.java))
        btnTimer.text = "STOP FLOATING TIMER"
    }

    private fun openPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        } else {
            data.data?.let { uris.add(it) }
        }
        for (u in uris) handleFile(u)
        refreshStatus()
        checkReady()
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) return c.getString(idx) ?: "file"
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: "file"
    }

    private fun readHead(uri: Uri): ByteArray {
        val buf = ByteArray(32)
        var n = 0
        try {
            contentResolver.openInputStream(uri)?.use { s ->
                while (n < buf.size) {
                    val r = s.read(buf, n, buf.size - n)
                    if (r <= 0) break
                    n += r
                }
            }
        } catch (_: Exception) {
            n = 0
        }
        return buf.copyOf(n)
    }

    private fun handleFile(uri: Uri) {
        val name = displayName(uri)
        val h = readHead(uri)

        val isElf = h.size >= 20 &&
            h[0] == 0x7F.toByte() && h[1] == 'E'.code.toByte() &&
            h[2] == 'L'.code.toByte() && h[3] == 'F'.code.toByte()
        val isMeta = h.size >= 4 &&
            h[0] == 0xAF.toByte() && h[1] == 0x1B.toByte() &&
            h[2] == 0xB1.toByte() && h[3] == 0xFA.toByte()

        if (isElf) {
            val eType = (h[16].toInt() and 0xFF) or ((h[17].toInt() and 0xFF) shl 8)
            val machine = (h[18].toInt() and 0xFF) or ((h[19].toInt() and 0xFF) shl 8)
            if (eType == 3) { // ET_DYN = shared object (.so)
                val arch = when (machine) {
                    0x28 -> "ARM (32-bit)"
                    0xB7 -> "ARM64"
                    0x03 -> "x86"
                    0x3E -> "x86_64"
                    else -> "machine 0x" + Integer.toHexString(machine)
                }
                libUri = uri
                libInfo = "$name, ELF shared object, $arch"
                log("LIB accepted: $name [$arch]")
                return
            }
        }
        if (isMeta) {
            metaUri = uri
            metaXor = 0
            log("META DATA accepted: $name")
            return
        }
        // Metadata obfuscated with a single-byte XOR key (all 4 magic bytes give the same key)
        if (h.size >= 8) {
            val k = (h[0].toInt() and 0xFF) xor 0xAF
            val ok = ((h[1].toInt() and 0xFF) xor 0x1B) == k &&
                ((h[2].toInt() and 0xFF) xor 0xB1) == k &&
                ((h[3].toInt() and 0xFF) xor 0xFA) == k
            if (k != 0 && ok) {
                metaUri = uri
                metaXor = k
                log("META DATA accepted: $name (XOR 0x${"%02X".format(k)} obfuscated, will be decoded)")
                return
            }
        }
        val hex = h.take(16).joinToString(" ") { "%02X".format(it) }
        log("$MSG_INVALID ($name)")
        log("Debug: size=${h.size} bytes read, first bytes: ${if (hex.isEmpty()) "(none)" else hex}")
        Toast.makeText(this, MSG_INVALID, Toast.LENGTH_LONG).show()
    }

    private fun refreshStatus() {
        val l = if (libUri != null) "LIB: OK" else "LIB: waiting"
        val m = if (metaUri != null) "META DATA: OK" else "META DATA: waiting"
        tvStatus.text = "$l   |   $m"
    }

    private fun checkReady() {
        if (busy) return
        if (libUri != null && metaUri != null) {
            startDump()
        } else if (libUri == null && metaUri != null) {
            log("Waiting for LIB file...")
        } else if (libUri != null && metaUri == null) {
            log("Waiting for META DATA file...")
        }
    }

    private fun startDump() {
        busy = true
        choiceBox.visibility = View.GONE
        progress.visibility = View.VISIBLE
        btnSend.isEnabled = false
        log("Both files received. Starting DUMP...")
        val mUri = metaUri!!
        val info = libInfo
        val xorKey = metaXor
        Thread {
            try {
                val bytes = contentResolver.openInputStream(mUri)!!.use { it.readBytes() }
                val out = File(cacheDir, "dump.cs")
                Il2CppMetaDumper.dump(bytes, xorKey, info, out) { msg -> runOnUiThread { log(msg) } }
                dumpFile = out
                runOnUiThread { finishDump(out) }
            } catch (t: Throwable) {
                runOnUiThread { failDump(t) }
            }
        }.start()
    }

    private fun finishDump(f: File) {
        busy = false
        progress.visibility = View.GONE
        btnSend.isEnabled = true
        log("DUMP finished: ${f.length() / 1024} KB")
        choiceBox.visibility = View.VISIBLE
    }

    private fun failDump(t: Throwable) {
        busy = false
        progress.visibility = View.GONE
        btnSend.isEnabled = true
        log("DUMP failed: ${t.message ?: t.javaClass.simpleName}")
        resetFiles()
    }

    private fun stamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun downloadDump() {
        val src = dumpFile ?: return
        try {
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "dump_${stamp()}.cs")
                put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("Cannot create file in Downloads")
            contentResolver.openOutputStream(uri)!!.use { o ->
                src.inputStream().use { it.copyTo(o) }
            }
            log("Downloaded to the Downloads folder.")
            Toast.makeText(this, "Saved to Downloads", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            log("Download failed: ${e.message}")
        }
        afterChoice()
    }

    private fun saveDump() {
        val src = dumpFile ?: return
        try {
            val dir = File(getExternalFilesDir(null), "dumps")
            dir.mkdirs()
            val dst = File(dir, "dump_${stamp()}.cs")
            src.copyTo(dst, overwrite = true)
            log("Saved: ${dst.absolutePath}")
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            log("Save failed: ${e.message}")
        }
        afterChoice()
    }

    private fun afterChoice() {
        choiceBox.visibility = View.GONE
        resetFiles()
        log("Ready for new files.")
    }

    private fun resetFiles() {
        libUri = null
        metaUri = null
        metaXor = 0
        libInfo = ""
        refreshStatus()
    }

    private fun log(s: String) {
        tvLog.append("\n$s")
        scrollLog.post { scrollLog.fullScroll(View.FOCUS_DOWN) }
    }
}
