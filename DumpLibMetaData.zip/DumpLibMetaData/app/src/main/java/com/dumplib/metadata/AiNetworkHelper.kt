package com.dumplib.metadata

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object AiNetworkHelper {
    private const val T = 60_000

    fun call(m: AiModule, msgs: List<ChatMessage>): String = when (m.apiType) {
        AiApiType.GEMINI -> gemini(m.apiUrl, m.model, m.apiKey, msgs)
        AiApiType.CLAUDE -> claude(m.apiUrl, m.model, m.apiKey, msgs)
        AiApiType.OPENAI -> openai(m.apiUrl, m.model, m.apiKey, msgs)
    }

    private fun post(url: String, body: String, h: Map<String,String>): Pair<Int,String> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.setRequestProperty("Content-Type","application/json; charset=utf-8")
        h.forEach { (k,v) -> c.setRequestProperty(k,v) }
        c.connectTimeout = T; c.readTimeout = T; c.doOutput = true
        c.outputStream.bufferedWriter(Charsets.UTF_8).use { it.write(body) }
        val code = c.responseCode
        val txt = (if (code==200) c.inputStream else (c.errorStream ?: c.inputStream))
            .bufferedReader(Charsets.UTF_8).readText()
        return code to txt
    }

    private fun msgsArr(msgs: List<ChatMessage>) = JSONArray().also { a ->
        msgs.forEach { m -> a.put(JSONObject().put("role",m.role).put("content",m.content)) }
    }

    private fun openai(url: String, model: String, key: String, msgs: List<ChatMessage>): String {
        val body = JSONObject().put("model",model).put("messages",msgsArr(msgs)).put("max_tokens",2048).toString()
        val (code,txt) = post("$url/chat/completions", body, mapOf("Authorization" to "Bearer $key"))
        if (code!=200) return "Error $code: ${errMsg(txt)}"
        return try { JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content") }
        catch (e:Exception) { "Parse error: ${e.message}" }
    }

    private fun gemini(url: String, model: String, key: String, msgs: List<ChatMessage>): String {
        val contents = JSONArray().also { a ->
            msgs.forEach { m -> a.put(JSONObject()
                .put("role", if(m.role=="assistant") "model" else "user")
                .put("parts", JSONArray().put(JSONObject().put("text",m.content)))) }
        }
        val (code,txt) = post("$url/models/$model:generateContent?key=$key",
            JSONObject().put("contents",contents).toString(), emptyMap())
        if (code!=200) return "Error $code: ${errMsg(txt)}"
        return try { JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text") }
        catch (e:Exception) { "Parse error: ${e.message}" }
    }

    private fun claude(url: String, model: String, key: String, msgs: List<ChatMessage>): String {
        val body = JSONObject().put("model",model).put("max_tokens",2048).put("messages",msgsArr(msgs)).toString()
        val (code,txt) = post("$url/v1/messages", body,
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"))
        if (code!=200) return "Error $code: ${errMsg(txt)}"
        return try { JSONObject(txt).getJSONArray("content").getJSONObject(0).getString("text") }
        catch (e:Exception) { "Parse error: ${e.message}" }
    }

    private fun errMsg(txt: String) = try {
        JSONObject(txt).optJSONObject("error")?.optString("message",txt) ?: txt.take(300)
    } catch (_:Exception) { txt.take(300) }
}
