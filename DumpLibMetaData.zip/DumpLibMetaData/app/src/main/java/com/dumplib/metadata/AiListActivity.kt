package com.dumplib.metadata

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*

class AiListActivity : Activity() {

    private lateinit var listBox: LinearLayout
    private lateinit var tvEmpty: TextView
    private var modules = mutableListOf<AiModule>()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_ai_list)
        listBox  = findViewById(R.id.aiListBox)
        tvEmpty  = findViewById(R.id.tvAiEmpty)
        findViewById<TextView>(R.id.btnAiMenu).setOnClickListener { showMenu(it) }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        modules = AiModule.load(this)
        listBox.removeAllViews()
        if (modules.isEmpty()) { tvEmpty.visibility = View.VISIBLE; return }
        tvEmpty.visibility = View.GONE
        modules.forEach { buildCard(it) }
    }

    private fun buildCard(m: AiModule) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16),dp(14),dp(16),dp(14))
            isClickable = true; isFocusable = true
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0xFF0E2730.toInt())
                setStroke(dp(1), 0xFF1DE9D1.toInt())
            }
            setOnClickListener {
                startActivity(Intent(this@AiListActivity, AiChatActivity::class.java)
                    .putExtra("moduleId", m.id))
            }
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0,0,0,dp(10))

        val tvName = TextView(this).apply {
            text = m.name; setTextColor(0xFF1DE9D1.toInt())
            textSize=16f; setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val tvSub = TextView(this).apply {
            text = "${m.apiType.label}  •  ${m.model}"
            setTextColor(0xFF8FB3BA.toInt()); textSize=12f
        }
        card.addView(tvName); card.addView(tvSub)
        listBox.addView(card, lp)
    }

    private fun showMenu(anchor: View) {
        val p = PopupMenu(this, anchor)
        p.menu.add(0,1,0,"New AI")
        p.menu.add(0,2,0,"Delete All")
        p.setOnMenuItemClickListener { item ->
            when(item.itemId) { 1 -> showCreate(); 2 -> confirmDeleteAll() }; true
        }
        p.show()
    }

    private fun showCreate() {
        val sv = android.widget.ScrollView(this)
        val lay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20),dp(8),dp(20),dp(8))
        }
        sv.addView(lay)

        // ── Presets row ──
        lay.addView(smallLabel("Quick presets:"))
        val hScroll = HorizontalScrollView(this); val preRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        hScroll.addView(preRow); lay.addView(hScroll)
        lay.addView(spacer(10))

        // ── Fields ──
        val etName  = field("Name")
        val etUrl   = field("API URL  e.g. https://api.openai.com/v1")
        val etModel = field("Model  e.g. gpt-4o")
        val etKey   = field("API Key", password=true)

        val typeLabels = AiApiType.values().map { it.label }.toTypedArray()
        val spType = Spinner(this).apply {
            adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, typeLabels)
            val lp2 = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp2.setMargins(0,dp(2),0,dp(10)); layoutParams=lp2
        }

        AiModule.PRESETS.forEach { preset ->
            val btn = Button(this).apply {
                text=preset.name; textSize=11f; setPadding(dp(10),dp(4),dp(10),dp(4))
                setTextColor(0xFF1DE9D1.toInt())
                backgroundTintList = ColorStateList.valueOf(0xFF14323A.toInt())
                val lp2 = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp2.setMargins(0,0,dp(6),0); layoutParams=lp2
                setOnClickListener {
                    etName.setText(preset.name); etUrl.setText(preset.url); etModel.setText(preset.model)
                    spType.setSelection(preset.type.ordinal)
                }
            }
            preRow.addView(btn)
        }

        lay.apply {
            addView(smallLabel("Name")); addView(etName)
            addView(smallLabel("API URL")); addView(etUrl)
            addView(smallLabel("Model")); addView(etModel)
            addView(smallLabel("API Type")); addView(spType)
            addView(smallLabel("API Key")); addView(etKey)
        }

        AlertDialog.Builder(this)
            .setTitle("New AI")
            .setView(sv)
            .setPositiveButton("Save") { _,_ ->
                val name  = etName.text.toString().trim()
                val url   = etUrl.text.toString().trim()
                val model = etModel.text.toString().trim()
                val key   = etKey.text.toString().trim()
                if (name.isEmpty() || url.isEmpty() || model.isEmpty() || key.isEmpty()) {
                    Toast.makeText(this,"All fields are required",Toast.LENGTH_SHORT).show(); return@setPositiveButton
                }
                val mod = AiModule(name=name, apiUrl=url, model=model, apiKey=key,
                    apiType=AiApiType.values()[spType.selectedItemPosition])
                modules.add(mod); AiModule.save(this, modules); refresh()
                Toast.makeText(this,"${name} saved",Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel",null).show()
    }

    private fun confirmDeleteAll() {
        AlertDialog.Builder(this).setTitle("Delete All AI")
            .setMessage("Remove all AI modules? This cannot be undone.")
            .setPositiveButton("Delete") { _,_ -> AiModule.save(this, emptyList()); refresh() }
            .setNegativeButton("Cancel",null).show()
    }

    private fun field(hint: String, password: Boolean=false) = EditText(this).apply {
        this.hint=hint; setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF5A7A82.toInt())
        setPadding(dp(10),dp(10),dp(10),dp(10))
        if (password) inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val lp2=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp2.setMargins(0,dp(2),0,dp(8)); layoutParams=lp2
    }
    private fun smallLabel(t: String) = TextView(this).apply {
        text=t; setTextColor(0xFF8FB3BA.toInt()); textSize=11f
    }
    private fun spacer(d: Int) = View(this).apply {
        layoutParams=LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(d))
    }
    private fun dp(v:Int) = (v*resources.displayMetrics.density).toInt()
}
