package com.dumplib.metadata

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ChatMessage(val role: String, val content: String)

enum class AiApiType(val label: String) {
    OPENAI("OpenAI-compatible"),
    GEMINI("Gemini – Google"),
    CLAUDE("Claude – Anthropic")
}

data class AiModule(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val apiUrl: String,
    val model: String,
    val apiKey: String,
    val apiType: AiApiType = AiApiType.OPENAI
) {
    companion object {
        data class Preset(val name: String, val url: String, val model: String, val type: AiApiType)
        val PRESETS = listOf(
            Preset("ChatGPT",  "https://api.openai.com/v1",                            "gpt-4o",            AiApiType.OPENAI),
            Preset("Gemini",   "https://generativelanguage.googleapis.com/v1beta",     "gemini-1.5-pro",    AiApiType.GEMINI),
            Preset("Claude 5.5","https://api.anthropic.com",                           "claude-sonnet-5-5", AiApiType.CLAUDE),
            Preset("Claude 4.6","https://api.anthropic.com",                           "claude-sonnet-4-6", AiApiType.CLAUDE),
            Preset("DeepSeek", "https://api.deepseek.com",                             "deepseek-chat",     AiApiType.OPENAI),
            Preset("Grok",     "https://api.x.ai/v1",                                 "grok-4",            AiApiType.OPENAI)
        )
        fun load(ctx: Context): MutableList<AiModule> {
            val str = ctx.getSharedPreferences("ai_mods", Context.MODE_PRIVATE)
                .getString("list","[]") ?: "[]"
            return try {
                val a = JSONArray(str)
                (0 until a.length()).mapNotNull { i ->
                    runCatching {
                        val o = a.getJSONObject(i)
                        AiModule(id=o.optString("id",UUID.randomUUID().toString()),
                            name=o.getString("name"), apiUrl=o.getString("apiUrl"),
                            model=o.getString("model"), apiKey=o.getString("apiKey"),
                            apiType=AiApiType.valueOf(o.optString("apiType","OPENAI")))
                    }.getOrNull()
                }.toMutableList()
            } catch (_:Exception) { mutableListOf() }
        }
        fun save(ctx: Context, list: List<AiModule>) {
            val a = JSONArray()
            list.forEach { m -> a.put(JSONObject().apply {
                put("id",m.id); put("name",m.name); put("apiUrl",m.apiUrl)
                put("model",m.model); put("apiKey",m.apiKey); put("apiType",m.apiType.name) }) }
            ctx.getSharedPreferences("ai_mods",Context.MODE_PRIVATE)
                .edit().putString("list",a.toString()).apply()
        }
    }
}
