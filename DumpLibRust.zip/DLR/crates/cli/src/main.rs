use std::io::{BufRead,Write};
fn main(){
    let args:Vec<String>=std::env::args().collect();
    match args.get(1).map(|s|s.as_str()){
        Some("dump") =>cmd_dump(&args[2..]),
        Some("ai")   =>cmd_ai(&args[2..]),
        Some("chat") =>cmd_chat(&args[2..]),
        _            =>usage(),
    }
}
fn get(args:&[String],flag:&str)->Option<String>{
    args.windows(2).find(|w|w[0]==flag).map(|w|w[1].clone())
}
fn cmd_dump(args:&[String]){
    let path=match args.first(){Some(p)=>p,None=>{eprintln!("Usage: dumplib dump <file> [--out dump.cs]");return;}};
    let mut data=std::fs::read(path).expect("Cannot read file");
    if let Some(k)=dump_core::detect_xor(&data){eprintln!("XOR key: 0x{k:02X}");dump_core::xor_decode(&mut data,k);}
    match dump_core::dump(&data){
        Ok(r)=>match get(args,"--out"){
            Some(o)=>{std::fs::write(&o,&r).expect("Write failed");println!("Saved to {o}");}
            None   =>print!("{r}"),
        },
        Err(e)=>eprintln!("Error: {e}"),
    }
}
fn cmd_ai(args:&[String]){
    let typ=get(args,"--type").unwrap_or_else(||"openai".into());
    let url=get(args,"--url").unwrap_or_else(||default_url(&typ));
    let model=get(args,"--model").unwrap_or_else(||default_model(&typ));
    let key=get(args,"--key").expect("--key required");
    let msg=args.last().expect("message required");
    let client=ai_core::AiClient::new(ai_core::ApiType::from_str(&typ),url,model,key);
    let msgs=vec![ai_core::Message{role:"user".into(),content:msg.clone()}];
    match client.chat(&msgs){Ok(r)=>println!("{r}"),Err(e)=>eprintln!("Error: {e}")}
}
fn cmd_chat(args:&[String]){
    let typ=get(args,"--type").unwrap_or_else(||"openai".into());
    let url=get(args,"--url").unwrap_or_else(||default_url(&typ));
    let model=get(args,"--model").unwrap_or_else(||default_model(&typ));
    let key=get(args,"--key").expect("--key required");
    let client=ai_core::AiClient::new(ai_core::ApiType::from_str(&typ),url.clone(),model.clone(),key);
    let mut history:Vec<ai_core::Message>=Vec::new();
    println!("── DumpLib AI Chat ({model}) ──  type 'quit' to exit");
    let stdin=std::io::stdin();
    loop{
        print!("You: ");std::io::stdout().flush().unwrap();
        let mut line=String::new();
        stdin.lock().read_line(&mut line).unwrap();
        let line=line.trim().to_string();
        if line.eq_ignore_ascii_case("quit")||line.eq_ignore_ascii_case("exit"){break;}
        if line.is_empty(){continue;}
        history.push(ai_core::Message{role:"user".into(),content:line});
        match client.chat(&history){
            Ok(r)=>{println!("AI:  {r}");history.push(ai_core::Message{role:"assistant".into(),content:r});}
            Err(e)=>eprintln!("Error: {e}"),
        }
    }
}
fn default_url(t:&str)->String{match t{"gemini"=>"https://generativelanguage.googleapis.com/v1beta","claude"=>"https://api.anthropic.com","grok"=>"https://api.x.ai/v1","deepseek"=>"https://api.deepseek.com",_=>"https://api.openai.com/v1"}.into()}
fn default_model(t:&str)->String{match t{"gemini"=>"gemini-1.5-pro","claude"=>"claude-sonnet-5-5","grok"=>"grok-4","deepseek"=>"deepseek-chat",_=>"gpt-4o"}.into()}
fn usage(){
    println!("DUMP LIB + META DATA — Rust CLI\n");
    println!("  dumplib dump <file> [--out dump.cs]");
    println!("  dumplib ai  --type openai|gemini|claude|grok|deepseek --key KEY [--url URL] [--model M] \"msg\"");
    println!("  dumplib chat --type ... --key KEY   (interactive)");
}
