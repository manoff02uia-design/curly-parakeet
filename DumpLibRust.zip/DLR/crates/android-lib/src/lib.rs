use jni::JNIEnv;
use jni::objects::{JByteArray,JClass,JString};
use jni::sys::jstring;

#[no_mangle]
pub extern "system" fn Java_com_dumplib_metadata_RustBridge_dump(
    mut env:JNIEnv, _cls:JClass, meta:JByteArray, _info:JString
)->jstring{
    let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||->String{
        let mut bytes:Vec<u8>=env.convert_byte_array(&meta).unwrap_or_default();
        if let Some(k)=dump_core::detect_xor(&bytes){dump_core::xor_decode(&mut bytes,k);}
        dump_core::dump(&bytes).unwrap_or_else(|e|format!("ERROR: {e}"))
    })).unwrap_or_else(|_|"PANIC in Rust dump".to_string());
    env.new_string(result).unwrap().into_raw()
}

#[no_mangle]
pub extern "system" fn Java_com_dumplib_metadata_RustBridge_aiChat(
    mut env:JNIEnv, _cls:JClass,
    api_type:JString, url:JString, model:JString,
    key:JString, msgs_json:JString
)->jstring{
    let result=std::panic::catch_unwind(std::panic::AssertUnwindSafe(||->String{
        let gs=|s:&JString|->String{env.get_string(s).map(|s|s.into()).unwrap_or_default()};
        let typ=gs(&api_type);let u=gs(&url);let m=gs(&model);
        let k=gs(&key);let mj=gs(&msgs_json);
        let msgs:Vec<ai_core::Message>=match serde_json::from_str(&mj){
            Ok(v)=>v, Err(e)=>return format!("ERROR JSON: {e}")
        };
        let client=ai_core::AiClient::new(ai_core::ApiType::from_str(&typ),u,m,k);
        client.chat(&msgs).unwrap_or_else(|e|format!("ERROR: {e}"))
    })).unwrap_or_else(|_|"PANIC in Rust ai".to_string());
    env.new_string(result).unwrap().into_raw()
}
