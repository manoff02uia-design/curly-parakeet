//! IL2CPP global-metadata.dat parser (versions 24-31)
use std::fmt::Write;
const MAGIC:u32=0xFAB11BAF;
fn i32le(d:&[u8],o:usize)->i32{i32::from_le_bytes(d[o..o+4].try_into().unwrap())}
fn u16le(d:&[u8],o:usize)->u16{u16::from_le_bytes(d[o..o+2].try_into().unwrap())}
fn u32le(d:&[u8],o:usize)->u32{u32::from_le_bytes(d[o..o+4].try_into().unwrap())}
pub fn detect_xor(d:&[u8])->Option<u8>{
    if d.len()<8{return None;}
    let k=d[0]^0xAF;if k==0{return None;}
    if [0xAFu8,0x1B,0xB1,0xFA].iter().enumerate().all(|(i,&b)|d[i]^k==b){Some(k)}else{None}
}
pub fn xor_decode(d:&mut[u8],key:u8){d.iter_mut().for_each(|b|*b^=key);}
pub fn dump(data:&[u8])->Result<String,String>{
    if data.len()<256{return Err("File too small".into());}
    if u32le(data,0)!=MAGIC{return Err(format!("Bad magic 0x{:08X}",u32le(data,0)));}
    let ver=i32le(data,4);
    if !(24..=31).contains(&ver){return Err(format!("Version {ver} not supported (24-31)"));}
    let str_off=i32le(data,24)as usize;let str_sz=i32le(data,28)as usize;
    let mth_off=i32le(data,48)as usize;let mth_sz=i32le(data,52)as usize;
    let fld_off=i32le(data,96)as usize;let fld_sz=i32le(data,100)as usize;
    let td_off =i32le(data,160)as usize;let td_sz =i32le(data,164)as usize;
    let chk=|o:usize,s:usize|s>0&&o+s<=data.len();
    if !chk(str_off,str_sz)||!chk(td_off,td_sz)||!chk(mth_off,mth_sz.max(1)-1)||!chk(fld_off,fld_sz.max(1)-1){
        return Err("Invalid header (file may be encrypted)".into());
    }
    let gs=|idx:i32|->Option<&str>{
        if idx<0||idx as usize>=str_sz{return None;}
        let s=str_off+idx as usize;
        let e=data[s..str_off+str_sz].iter().position(|&b|b==0).map(|p|s+p).unwrap_or(str_off+str_sz);
        std::str::from_utf8(&data[s..e]).ok()
    };
    let vs=|s:Option<&str>|s.map_or(false,|t|!t.is_empty()&&t.chars().all(|c|c as u32>=32&&c!='\u{FFFD}'));
    let ft=fld_sz/12;
    let ts=(80usize..=140).step_by(4).find(|&ts|{
        if td_sz%ts!=0{return false;}
        (0..(td_sz/ts).min(3000)).all(|i|{
            let b=td_off+i*ts;
            if !vs(gs(i32le(data,b)))||gs(i32le(data,b+4)).is_none(){return false;}
            let fc=u16le(data,b+ts-20)as usize;
            fc==0||(i32le(data,b+ts-56)as usize)+fc<=ft
        })
    }).ok_or("Cannot detect TypeDef layout")?;
    let tc=td_sz/ts;
    let ms=if mth_sz>0{(24usize..=80).step_by(4).find(|&ms|{
        if mth_sz%ms!=0{return false;}
        (0..mth_sz/ms).all(|i|{
            let b=mth_off+i*ms;
            if !vs(gs(i32le(data,b))){return false;}
            let dt=i32le(data,b+4)as usize;if dt>=tc{return false;}
            let tb=td_off+dt*ts;
            let ms0=i32le(data,tb+ts-52)as usize;
            let mc=u16le(data,tb+ts-24)as usize;
            ms0<=i&&i<ms0+mc
        })
    }).unwrap_or(0)}else{0};
    let mut out=String::new();
    writeln!(out,"// DUMP LIB + META DATA — Rust").unwrap();
    writeln!(out,"// v{ver}  types:{tc}  td-stride:{ts}  mth-stride:{ms}").unwrap();
    writeln!(out).unwrap();
    let(mut tf,mut tm)=(0usize,0usize);
    for i in 0..tc{
        let b=td_off+i*ts;
        let name=gs(i32le(data,b)).unwrap_or("?");
        let ns  =gs(i32le(data,b+4)).unwrap_or("");
        let flg =i32le(data,b+ts-60)as u32;
        let fs  =i32le(data,b+ts-56)as usize;
        let ms0 =i32le(data,b+ts-52)as usize;
        let mc  =u16le(data,b+ts-24)as usize;
        let fc  =u16le(data,b+ts-20)as usize;
        let tok =u32le(data,b+ts-4);
        let isi =(flg&0x20)!=0;
        writeln!(out,"// Namespace: {ns}").unwrap();
        write!(out,"{}{} {name}",amods(flg,isi),if isi{"interface"}else{"class"}).unwrap();
        writeln!(out," // TypeDefIndex:{i} Token:0x{tok:08X}").unwrap();
        writeln!(out,"{{").unwrap();
        if fc>0{
            writeln!(out,"\t// Fields").unwrap();
            for f in fs..fs+fc{
                let fb=fld_off+f*12;
                writeln!(out,"\t<type#{}> {};",i32le(data,fb+4),gs(i32le(data,fb)).unwrap_or("?")).unwrap();
                tf+=1;
            }
        }
        if mc>0&&ms>0{
            writeln!(out,"\t// Methods").unwrap();
            for k in ms0..ms0+mc{
                let mb=mth_off+k*ms;
                writeln!(out,"\t{}<ret> {}({} params); // Token:0x{:08X}",
                    mmods(u16le(data,mb+ms-8)),
                    gs(i32le(data,mb)).unwrap_or("?"),
                    u16le(data,mb+ms-2),
                    u32le(data,mb+ms-12)).unwrap();
                tm+=1;
            }
        }
        writeln!(out,"}}").unwrap();writeln!(out).unwrap();
    }
    writeln!(out,"// total: {tc} types, {tf} fields, {tm} methods").unwrap();
    Ok(out)
}
fn amods(f:u32,is_if:bool)->String{
    let mut s=match f&7{1|2=>"public ",3=>"private ",4=>"protected ",5=>"internal ",6=>"private protected ",_=>"internal "}.to_string();
    if !is_if{match((f&0x80)!=0,(f&0x100)!=0){(true,true)=>s.push_str("static "),(true,false)=>s.push_str("abstract "),(false,true)=>s.push_str("sealed "),_=>{}}}
    s
}
fn mmods(f:u16)->String{
    let mut s=match f&7{1=>"private ",2=>"private protected ",3=>"internal ",4=>"protected ",5=>"protected internal ",6=>"public ",_=>""}.to_string();
    if(f&0x10)!=0{s.push_str("static ");}
    if(f&0x400)!=0{s.push_str("abstract ");}else if(f&0x40)!=0{s.push_str("virtual ");}
    s
}
