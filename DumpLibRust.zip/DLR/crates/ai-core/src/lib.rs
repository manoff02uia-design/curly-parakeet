use serde::{Deserialize,Serialize};
#[derive(Debug,Clone,Serialize,Deserialize)]
pub struct Message{pub role:String,pub content:String}
#[derive(Debug,Clone,PartialEq)]
pub enum ApiType{OpenAI,Gemini,Claude}
impl ApiType{
    pub fn from_str(s:&str)->Self{
        match s.to_lowercase().as_str(){"gemini"=>Self::Gemini,"claude"=>Self::Claude,_=>Self::OpenAI}
    }
}
pub struct AiClient{pub api_type:ApiType,pub url:String,pub model:String,pub key:String}
impl AiClient{
    pub fn new(api_type:ApiType,url:String,model:String,key:String)->Self{Self{api_type,url,model,key}}
    pub fn chat(&self,msgs:&[Message])->Result<String,String>{
        match self.api_type{
            ApiType::OpenAI=>self.openai(msgs),
            ApiType::Gemini=>self.gemini(msgs),
            ApiType::Claude=>self.claude(msgs),
        }
    }
    fn post(&self,url:&str,body:&serde_json::Value,hdrs:&[(&str,&str)])->Result<serde_json::Value,String>{
        let mut req=ureq::post(url).set("Content-Type","application/json");
        for(k,v)in hdrs{req=req.set(k,v);}
        match req.send_string(&body.to_string()){
            Ok(r)=>r.into_json::<serde_json::Value>().map_err(|e|e.to_string()),
            Err(ureq::Error::Status(code,r))=>{
                let msg=r.into_string().unwrap_or_default();
                let em=serde_json::from_str::<serde_json::Value>(&msg).ok()
                    .and_then(|v|v["error"]["message"].as_str().map(|s|s.to_string()))
                    .unwrap_or_else(||msg.chars().take(300).collect());
                Err(format!("HTTP {code}: {em}"))
            }
            Err(e)=>Err(e.to_string()),
        }
    }
    fn openai(&self,msgs:&[Message])->Result<String,String>{
        let j=self.post(&format!("{}/chat/completions",&self.url),
            &serde_json::json!({"model":&self.model,"messages":msgs,"max_tokens":2048}),
            &[("Authorization",&format!("Bearer {}",&self.key))])?;
        j["choices"][0]["message"]["content"].as_str().map(|s|s.to_string()).ok_or("Parse error".into())
    }
    fn gemini(&self,msgs:&[Message])->Result<String,String>{
        let contents:Vec<_>=msgs.iter().map(|m|serde_json::json!({
            "role":if m.role=="assistant"{"model"}else{"user"},
            "parts":[{"text":&m.content}]
        })).collect();
        let j=self.post(&format!("{}/models/{}:generateContent?key={}",&self.url,&self.model,&self.key),
            &serde_json::json!({"contents":contents}),&[])?;
        j["candidates"][0]["content"]["parts"][0]["text"].as_str().map(|s|s.to_string()).ok_or("Parse error".into())
    }
    fn claude(&self,msgs:&[Message])->Result<String,String>{
        let j=self.post(&format!("{}/v1/messages",&self.url),
            &serde_json::json!({"model":&self.model,"max_tokens":2048,"messages":msgs}),
            &[("x-api-key",&self.key),("anthropic-version","2023-06-01")])?;
        j["content"][0]["text"].as_str().map(|s|s.to_string()).ok_or("Parse error".into())
    }
}
