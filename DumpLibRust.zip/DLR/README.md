# DUMP LIB + META DATA — Rust Edition

## Crates
| Crate | Mô tả |
|---|---|
| `dump-core` | IL2CPP metadata parser (v24-31), tự detect XOR |
| `ai-core` | HTTP client cho OpenAI / Gemini / Claude / DeepSeek / Grok |
| `android-lib` | JNI bridge — build ra `libdumplib.so` cho Android |
| `cli` | CLI tool chạy trên máy tính |

## Build local
```
cargo build --release -p dumplib-cli
./target/release/dumplib dump global-metadata.dat --out dump.cs
./target/release/dumplib chat --type claude --key sk-ant-... 
```

## GitHub Actions
Push code → tự build:
- `so-arm64-v8a`, `so-armeabi-v7a`, `so-x86_64`, `so-x86` — dùng cho Android JNI
- `dumplib-cli-linux` — CLI cho Linux
- `dumplib-cli-windows` — CLI cho Windows

## Android JNI
```kotlin
object RustBridge {
    init { System.loadLibrary("dumplib") }
    external fun dump(metadata: ByteArray, libInfo: String): String
    external fun aiChat(apiType: String, url: String, model: String, key: String, msgsJson: String): String
}
```
